package it.unisa.diem.se.team3.dbinteract;

import it.unisa.diem.se.team3.models.Activity;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Decorator class to add query for activity and other related to it.
 */
public class ActivityDecorator extends DbDecorator {

    /**
     * Base constructor, used to get an instance of the DbInterface interface used by the decorator classes.
     *
     * @param db: a concrete implementation of DbInterface.
     */
    public ActivityDecorator(DbInterface db) {
        super(db);
    }

    /**
     * This method displays a list of Activity elements, which represent data from the activity and related tables,
     * based on the type of activity chosen.
     *
     * @param type: 'p' to view the scheduled tasks, 'e' to view the ewo tasks.
     * @return a list of Activity or null if an error occur.
     */
    public ArrayList<Activity> getActivity(char type) {
        ArrayList<Activity> result = new ArrayList<>();
        try (PreparedStatement stmt = getConn().prepareStatement(
                "SELECT a.id, a.year, a.week, a.day, a.interruptibility, a.estimated_intervention_time, a.description, mp.id AS procedure_id, mp.name AS procedure_name, mp.smp AS procedure_smp, mt.id AS typology_id, mt.name AS typology_name, mt.description AS typology_description, s.site_id, s.factory_name, s.area_name, s.workspace_id, s.workspace_description, m.id AS material_id, m.name AS material_name, m.description AS material_description " +
                        "FROM activity AS a LEFT JOIN maintenance_typologies AS mt ON a.maintenance_typologies = mt.id LEFT JOIN maintenance_procedures AS mp ON a.maintenance_procedures = mp.id LEFT JOIN site_view AS s ON a.site = s.site_id LEFT JOIN need AS n ON n.activity = a.id LEFT JOIN materials AS m ON n.materials = m.id " +
                        "WHERE a.type = ? AND a.id NOT IN (SELECT activity FROM assigned_activity) ORDER BY a.id, m.id;"
        )) {
            stmt.setString(1, String.valueOf(type));
            try (ResultSet rs = stmt.executeQuery()) {
                long prevActivityId = 0;
                while (rs.next()) {
                    long activityId = rs.getLong("id");
                    if (activityId != prevActivityId) {
                        result.add(new Activity(activityId, rs.getInt("year"),
                                rs.getShort("week"), rs.getShort("day"),
                                rs.getBoolean("interruptibility"), rs.getInt("estimated_intervention_time"),
                                rs.getString("description"), rs.getLong("typology_id"),
                                rs.getString("typology_name"), rs.getString("typology_description"),
                                rs.getLong("site_id"), rs.getString("factory_name") + "-" +
                                rs.getString("area_name"), rs.getLong("procedure_id"),
                                rs.getString("procedure_name"), rs.getLong("procedure_smp"),
                                rs.getLong("workspace_id"), rs.getString("workspace_description")));
                    }
                    long materialId = rs.getLong("material_id");
                    if (materialId != 0) {
                        result.get(result.size() - 1).addMaterial(materialId, rs.getString("material_name"),
                                rs.getString("material_description"));
                    }
                    prevActivityId = activityId;
                }
            }
        } catch (SQLException e) {
            return null;
        }
        return result;
    }

    /**
     * This method displays an Activity elements with the selected id, which represent data from the activity and
     * related tables.
     *
     * @param id: the id for the activity to view.
     * @return an Activity object, null if there are no activities with that id or an error occur.
     */
    public Activity getActivity(long id) {
        try (PreparedStatement stmt = getConn().prepareStatement(
                "SELECT a.id, a.year, a.week, a.day, a.interruptibility, a.estimated_intervention_time, a.description, mp.id AS procedure_id, mp.name AS procedure_name, mp.smp AS procedure_smp, mt.id AS typology_id, mt.name AS typology_name, mt.description AS typology_description, s.site_id, s.factory_name, s.area_name, s.workspace_id, s.workspace_description, m.id AS material_id, m.name AS material_name, m.description AS material_description " +
                        "FROM activity AS a LEFT JOIN maintenance_typologies AS mt ON a.maintenance_typologies = mt.id LEFT JOIN maintenance_procedures AS mp ON a.maintenance_procedures = mp.id LEFT JOIN site_view AS s ON a.site = s.site_id LEFT JOIN need AS n ON n.activity = a.id LEFT JOIN materials AS m ON n.materials = m.id WHERE a.id = ? ;"
        )) {
            stmt.setLong(1, id);
            Activity result;
            try (ResultSet rs = stmt.executeQuery()) {
                if (!rs.next()) {   // Not existing id
                    return null;
                }
                result = new Activity(rs.getLong("id"), rs.getInt("year"),
                        rs.getShort("week"), rs.getShort("day"),
                        rs.getBoolean("interruptibility"), rs.getInt("estimated_intervention_time"),
                        rs.getString("description"), rs.getLong("typology_id"),
                        rs.getString("typology_name"), rs.getString("typology_description"),
                        rs.getLong("site_id"), rs.getString("factory_name") + "-" +
                        rs.getString("area_name"), rs.getLong("procedure_id"),
                        rs.getString("procedure_name"), rs.getLong("procedure_smp"),
                        rs.getLong("workspace_id"), rs.getString("workspace_description"));
                do {
                    long materialId = rs.getLong("material_id");
                    if (materialId != 0) {
                        result.addMaterial(materialId, rs.getString("material_name"),
                                rs.getString("material_description"));
                    }
                } while (rs.next());
            }
            return result;
        } catch (SQLException e) {
            return null;
        }
    }

    /**
     * This method create a bew activity and store it into the database.
     *
     * @param year:                 the activity year;
     * @param week:                 the activity week;
     * @param day:                  the activity day;
     * @param type:                 the type of activity (planned p, ewo e);
     * @param interruptibility:     true if the activity is interruptible, otherwise false;
     * @param time:                 the estimated intervention time;
     * @param description:          the activity description;
     * @param typologyId:           the id of the maintenance typologies related to activity;
     * @param procedureId:          the id of the maintenance procedures related to activity;
     * @param siteId:               the id of the maintenance site related to activity;
     * @param materials:            the ids of the material needed for the activity;
     * @param workspaceDescription: the workspace notes description of the site related to the activity.
     * @return true if is correctly inserted, false if an error occur.
     */
    public boolean addActivity(int year, int week, int day, char type, boolean interruptibility, int time, String description,
                               long typologyId, long procedureId, long siteId, long[] materials, String workspaceDescription) {
        try (PreparedStatement stmt = getConn().prepareStatement(
                "INSERT INTO activity (id, year, week, day, type, interruptibility, estimated_intervention_time, description, maintenance_typologies, maintenance_procedures, site)" +
                        "VALUES (nextval('activity_id'), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"
        )) {
            stmt.setLong(1, year);
            stmt.setInt(2, week);
            if (day > 0) {
                stmt.setInt(3, day);
            } else {
                stmt.setNull(3, java.sql.Types.NULL);
            }
            stmt.setString(4, String.valueOf(type));
            stmt.setBoolean(5, interruptibility);
            if (time > 0) {
                stmt.setInt(6, time);
            } else {
                stmt.setNull(6, java.sql.Types.NULL);
            }
            stmt.setString(7, description);
            stmt.setLong(8, typologyId);
            stmt.setLong(9, procedureId);
            stmt.setLong(10, siteId);
            stmt.execute();

            long id;
            try (ResultSet rs = getConn().createStatement().executeQuery("SELECT currval('activity_id');")) {
                rs.next();
                id = rs.getLong(1);
            }
            addMaterialToActivity(id, materials);
            if(workspaceDescription != null) {
                editWorkspace(siteId, workspaceDescription);
            }

            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * This method edit an activity, identified by his id.
     *
     * @param id:                   the activity id to edit;
     * @param year:                 the new activity year;
     * @param week:                 the new activity week;
     * @param day:                  the new activity day;
     * @param type:                 the new type of activity (planned p, ewo e);
     * @param interruptibility:     true if the activity is interruptible, otherwise false;
     * @param time:                 the new estimated intervention time;
     * @param description:          the new activity description;
     * @param typologyId:           the new id of the maintenance typologies related to activity;
     * @param procedureId:          the new id of the maintenance procedures related to activity;
     * @param siteId:               the new id of the maintenance site related to activity;
     * @param materials:            the new ids of the material needed for the activity;
     * @param workspaceDescription: the new workspace notes description of the site related to the activity.
     * @return true if is correctly inserted, false if an error occur.
     */
    public boolean editActivity(long id, int year, int week, int day, char type, boolean interruptibility, int time, String description,
                                long typologyId, long procedureId, long siteId, long[] materials, String workspaceDescription) {
        try (PreparedStatement stmt = getConn().prepareStatement(
                "UPDATE activity SET year = ?, week = ?, day = ?, type = ?, interruptibility = ?, estimated_intervention_time = ?, " +
                        "description = ? , maintenance_typologies = ?, maintenance_procedures = ?, site = ? WHERE id = ?;"
        )) {
            stmt.setLong(1, year);
            stmt.setInt(2, week);
            if (day > 0) {
                stmt.setInt(3, day);
            } else {
                stmt.setNull(3, java.sql.Types.NULL);
            }
            stmt.setString(4, String.valueOf(type));
            stmt.setBoolean(5, interruptibility);
            if (time > 0) {
                stmt.setInt(6, time);
            } else {
                stmt.setNull(6, java.sql.Types.NULL);
            }
            stmt.setString(7, description);
            stmt.setLong(8, typologyId);
            stmt.setLong(9, procedureId);
            stmt.setLong(10, siteId);
            stmt.setLong(11, id);
            stmt.execute();

            addMaterialToActivity(id, materials);
            editWorkspace(siteId, workspaceDescription);

            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Delete an activity by his id.
     *
     * @param id: the id of the activity to delete.
     * @return true if is correctly deleted, false if an error occur.
     */
    public boolean deleteActivity(long id) {
        try (PreparedStatement stmt = getConn().prepareStatement(
                "DELETE FROM need WHERE activity = ?; DELETE FROM activity WHERE id = ? ;"
        )) {
            stmt.setLong(1, id);
            stmt.setLong(2, id);
            stmt.execute();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * On edit and add, edit the material related to an activity.
     *
     * @param id:        the id of the activity;
     * @param materials: the id of the materials to associate to the activity.
     * @throws SQLException if an error occur.
     */
    private void addMaterialToActivity(long id, long[] materials) throws SQLException {
        try (PreparedStatement stmt = getConn().prepareStatement(
                "DELETE FROM need WHERE activity = ?;"
        )) {
            stmt.setLong(1, id);
            stmt.execute();
            for (long material : materials) {
                try (PreparedStatement stm = getConn().prepareStatement(
                        "INSERT INTO need (activity, materials) VALUES (?, ?);"
                )) {
                    stm.setLong(1, id);
                    stm.setLong(2, material);
                    stm.execute();
                }
            }
        }
    }

    /**
     * On edit and add, if the activity site has been associated a workspace notes, edit that. Else create new and
     * associate at the activity site.
     *
     * @param siteId:                  the id site linked to the workspace;
     * @param newWorkspaceDescription: the new workspace description.
     * @throws SQLException if an error occur.
     */
    private void editWorkspace(long siteId, String newWorkspaceDescription) throws SQLException {
        int res;
        try (PreparedStatement stmt = getConn().prepareStatement(
                "UPDATE workspace_notes SET description = ? WHERE " +
                        "id IN (SELECT a.workspace_notes FROM area AS a JOIN site s on a.id = s.area WHERE s.id = ?) AND " +
                        "(SELECT a.workspace_notes FROM area AS a JOIN site s on a.id = s.area WHERE s.id = ?) IS NOT NULL;"
        )) {
            stmt.setString(1, newWorkspaceDescription);
            stmt.setLong(2, siteId);
            stmt.setLong(3, siteId);
            res = stmt.executeUpdate();
            if (res == 0) {
                try (PreparedStatement stm = getConn().prepareStatement(
                        "INSERT INTO workspace_notes (id, description) VALUES (nextval('workspace_notes_id'), ?);" +
                                "UPDATE area SET workspace_notes = currval('workspace_notes_id') WHERE id IN (SELECT area FROM site WHERE id = ?);"
                )) {
                    stm.setString(1, newWorkspaceDescription);
                    stm.setLong(2, siteId);
                    stm.execute();
                }
            }
        }
    }
}
