package it.unisa.diem.team3.dbinteract;

import it.unisa.diem.se.team3.dbinteract.ActivityDecorator;
import it.unisa.diem.se.team3.models.Activity;
import it.unisa.diem.se.team3.servlet.ServletUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ActivityDecoratorTest {
    private ActivityDecorator db;

    @BeforeEach
    void setUp() {
        ServletUtil.setPropertyFilePath("./src/test/resources/config.properties");
        db = new ActivityDecorator(ServletUtil.connectDb());
        db.connect();

        String populateQuery = "INSERT INTO materials (id, name, description)  " +
                "VALUES (nextval('materials_id'), 'Material 1', 'Description Material 1.'),  " +
                "(nextval('materials_id'), 'Material 2', 'Description Material 2.'),  " +
                "(nextval('materials_id'), 'Material 3', 'Description Material 3.'); " +
                "INSERT INTO maintenance_typologies (id, name, description)  " +
                "VALUES (1, 'Typologies 1', 'Description typologies 1'), " +
                "(2, 'Typologies 2', 'Description typologies 2'); " +
                "INSERT INTO maintenance_procedures (id, name)  " +
                "VALUES (1, 'Procedure 1'), (2, 'Procedure 2'); " +
                "INSERT INTO workspace_notes (id, description) VALUES (1, 'Description workspace notes 1'), (2, 'Description workspace notes 2'); " +
                "INSERT INTO factory_site (id, name) VALUES (1, 'Factory Site 1'); " +
                "INSERT INTO area (id, name, factory_site, workspace_notes) VALUES (1, 'Area 1', 1, 1), (2, 'Area 2', 1, null); " +
                "INSERT INTO site (id, factory_site, area) VALUES (1, 1, 1), (2, 1, 2); " +
                "ALTER SEQUENCE workspace_notes_id RESTART WITH 3;" +
                "INSERT INTO activity (id, year, week, type, interruptibility, estimated_intervention_time, description, " +
                "maintenance_typologies, maintenance_procedures, site)  " +
                "VALUES (nextval('activity_id'), 2020, 21, 'p', true, 30, 'Activity 1 description.', 1, 1, 1), " +
                "(nextval('activity_id'), 2020, 21, 'e', true, 90, 'Activity 2 description.', 2, 1, 2), " +
                "(nextval('activity_id'), 2020, 21, 'p', true, 20, 'Activity 3 description.', 2, 2, 1), " +
                "(nextval('activity_id'), 2020, 21, 'p', true, 40, 'Activity 4 description.', 1, 2, 2); " +
                "INSERT INTO need (activity, materials) " +
                "VALUES (1, 1), (1, 2), (1, 3), (3, 1), (4, 1), (4, 3);" +
                "ALTER SEQUENCE activity_id RESTART WITH 5;";
        try (Statement stmt = db.getConn().createStatement()){
            stmt.execute(populateQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @AfterEach
    void tearDown() {
        String deleteQuery = "DELETE FROM need CASCADE; " +
                "DELETE FROM activity CASCADE; ALTER SEQUENCE activity_id RESTART WITH 1; " +
                "DELETE FROM materials CASCADE; ALTER SEQUENCE materials_id RESTART WITH 1; " +
                "DELETE FROM maintenance_typologies CASCADE; " +
                "DELETE FROM maintenance_procedures CASCADE; " +
                "DELETE FROM site CASCADE; " +
                "DELETE FROM area CASCADE;" +
                "DELETE FROM factory_site CASCADE; " +
                "ALTER SEQUENCE workspace_notes_id RESTART WITH 1;" +
                "DELETE FROM workspace_notes CASCADE;" +
                "ALTER SEQUENCE activity_id RESTART WITH 1;";
        try (Statement stmt = db.getConn().createStatement()){
            stmt.execute(deleteQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        db.disconnect();
    }

    @Test
    void getActivityByType() {
        // Actual
        List<Activity> actual = db.getActivity('p');

        // Expected
        ArrayList<Activity> expected = new ArrayList<>();
        Activity a = new Activity(1, 2020, 21, true, 30,
                "Activity 1 description.", 1, "Typologies 1",
                "Description typologies 1", 1, "Factory Site 1-Area 1", 1,
                "Procedure 1", 0, 1, "Description workspace notes 1");
        a.addMaterial(1, "Material 1", "Description Material 1.");
        a.addMaterial(2, "Material 2", "Description Material 2.");
        a.addMaterial(3, "Material 3", "Description Material 3.");
        expected.add(a);
        Activity a3 = new Activity(3, 2020, 21, true, 20,
                "Activity 3 description.", 2, "Typologies 2",
                "Description typologies 2", 1, "Factory Site 1-Area 1", 2,
                "Procedure 2", 0, 1, "Description workspace notes 1");
        a3.addMaterial(1, "Material 1", "Description Material 1.");
        expected.add(a3);
        Activity a4 = new Activity(4, 2020, 21, true, 40,
                "Activity 4 description.", 1, "Typologies 1",
                "Description typologies 1", 2, "Factory Site 1-Area 2", 2,
                "Procedure 2", 0, 0, null);
        a4.addMaterial(1, "Material 1", "Description Material 1.");
        a4.addMaterial(3, "Material 3", "Description Material 3.");
        expected.add(a4);

        // Match
        assertEquals(expected, actual);
    }

    @Test
    void getActivityById() {
        // Actual
        Activity actual = db.getActivity(3);

        // Expected
        Activity a3 = new Activity(3, 2020, 21, true, 20,
                "Activity 3 description.", 2, "Typologies 2",
                "Description typologies 2", 1, "Factory Site 1-Area 1", 2,
                "Procedure 2", 0, 1, "Description workspace notes 1");
        a3.addMaterial(1, "Material 1", "Description Material 1.");

        // Match
        assertEquals(a3, actual);
    }

    @Test
    void getActivityByNotExistingId() {
        // Actual
        Activity actual = db.getActivity(7);

        // Check
        assertNull(actual);
    }

    @Test
    void addActivity() {
        assertTrue(db.addActivity(2020, 23, 'e', false, 0, null, 1, 1, 1, new long[]{1, 2}, "New description 1"));
        assertTrue(db.addActivity(2020, 23, 'p', false, 30, "New activity description", 1, 1, 2, new long[]{}, "New description 2"));

        // Expected
        Activity a5 = new Activity(5, 2020, 23, false, 0,
                null, 1, "Typologies 1",
                "Description typologies 1", 1, "Factory Site 1-Area 1", 1,
                "Procedure 1", 0, 1, "New description 1");
        a5.addMaterial(1, "Material 1", "Description Material 1.");
        a5.addMaterial(2, "Material 2", "Description Material 2.");

        Activity a6 = new Activity(6, 2020, 23, false, 30,
                "New activity description", 1, "Typologies 1",
                "Description typologies 1", 2, "Factory Site 1-Area 2", 1,
                "Procedure 1", 0, 3, "New description 2");

        assertEquals(a5, db.getActivity(5));
        assertEquals(a6, db.getActivity(6));
    }

    @Test
    void editActivity() {
        assertTrue(db.editActivity(2, 2020, 22, 'e', false, 0, null, 1, 1, 2, new long[]{1, 2}, ""));
        assertTrue(db.editActivity(3, 2020, 22, 'e', false, 12, null, 1, 1, 1, new long[]{1, 2}, "New description 1"));

        Activity a2 = new Activity(2, 2020, 22, false, 0,
                null, 1, "Typologies 1",
                "Description typologies 1", 2, "Factory Site 1-Area 2", 1,
                "Procedure 1", 0, 3, "");
        a2.addMaterial(1, "Material 1", "Description Material 1.");
        a2.addMaterial(2, "Material 2", "Description Material 2.");

        assertEquals(a2, db.getActivity(2));

        Activity a3 = new Activity(3, 2020, 22, false, 12,
                null, 1, "Typologies 1",
                "Description typologies 1", 1, "Factory Site 1-Area 1", 1,
                "Procedure 1", 0, 1, "New description 1");
        a3.addMaterial(1, "Material 1", "Description Material 1.");
        a3.addMaterial(2, "Material 2", "Description Material 2.");

        assertEquals(a3, db.getActivity(3));
    }

    @Test
    void deleteActivity() {
        assertTrue(db.deleteActivity(1));

        // Actual
        List<Activity> actual = db.getActivity('p');

        // Expected
        ArrayList<Activity> expected = new ArrayList<>();
        Activity a3 = new Activity(3, 2020, 21, true, 20,
                "Activity 3 description.", 2, "Typologies 2",
                "Description typologies 2", 1, "Factory Site 1-Area 1", 2,
                "Procedure 2", 0, 1, "Description workspace notes 1");
        a3.addMaterial(1, "Material 1", "Description Material 1.");
        expected.add(a3);
        Activity a4 = new Activity(4, 2020, 21, true, 40,
                "Activity 4 description.", 1, "Typologies 1",
                "Description typologies 1", 2, "Factory Site 1-Area 2", 2,
                "Procedure 2", 0, 0, null);
        a4.addMaterial(1, "Material 1", "Description Material 1.");
        a4.addMaterial(3, "Material 3", "Description Material 3.");
        expected.add(a4);

        assertEquals(expected, actual);
    }
}