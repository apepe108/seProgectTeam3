package it.unisa.diem.se.team3.servlet;

import it.unisa.diem.se.team3.dbinteract.AvailabilityDecorator;
import org.eclipse.jetty.http.HttpStatus;
import org.junit.jupiter.api.*;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;

import static org.junit.jupiter.api.Assertions.*;

class AvailabilityServletTest {
    private AvailabilityDecorator db;
    private static ServletTester tester;

    @BeforeAll
    static void beforeAll() throws Exception {
        tester = new ServletTester(AvailabilityServlet.class, new String[]{"/availability-weekly", "/availability-daily"});
        tester.startServer();
    }

    @AfterAll
    static void afterAll() throws Exception {
        tester.shutdownServer();
    }

    @BeforeEach
    void setUp() {
        ServletUtil.setPropertyFilePath("./src/test/resources/config.properties");
        db = new AvailabilityDecorator(ServletUtil.connectDb());
        db.connect();

        String populateQuery = "INSERT INTO materials (id, name, description)  " +
                "VALUES (nextval('materials_id'), 'Material 1', 'Description Material 1.'),  " +
                "(nextval('materials_id'), 'Material 2', 'Description Material 2.'),  " +
                "(nextval('materials_id'), 'Material 3', 'Description Material 3.'); " +
                "INSERT INTO maintenance_typologies (id, name, description)  " +
                "VALUES (1, 'Typologies 1', 'Description typologies 1'), " +
                "(2, 'Typologies 2', 'Description typologies 2'); " +
                "INSERT INTO maintenance_procedures (id, name)  " +
                "VALUES (1, 'Procedure 1'), (2, 'Procedure 2'); " +
                "INSERT INTO workspace_notes (id, description) VALUES (1, 'Description workspace notes 1'), (2, 'Description workspace notes 2'); " +
                "INSERT INTO factory_site (id, name) VALUES (1, 'Factory Site 1'); " +
                "INSERT INTO area (id, name, factory_site, workspace_notes) VALUES (1, 'Area 1', 1, 1), (2, 'Area 2', 1, null); " +
                "INSERT INTO site (id, factory_site, area) VALUES (1, 1, 1), (2, 1, 2); " +
                "ALTER SEQUENCE workspace_notes_id RESTART WITH 3;" +
                "INSERT INTO activity (id, year, week, day, type, interruptibility, estimated_intervention_time, description, " +
                "maintenance_typologies, maintenance_procedures, site)  " +
                "VALUES (nextval('activity_id'), 2020, 21, 1, 'p', true, 30, 'Activity 1 description.', 1, 1, 1), " +
                "(nextval('activity_id'), 2020, 21, 1, 'e', true, 90, 'Activity 2 description.', 2, 1, 2), " +
                "(nextval('activity_id'), 2020, 21, 1, 'p', true, 20, 'Activity 3 description.', 2, 2, 1), " +
                "(nextval('activity_id'), 2020, 21, 1, 'p', true, 40, 'Activity 4 description.', 1, 2, 2); " +
                "INSERT INTO need (activity, materials) " +
                "VALUES (1, 1), (1, 2), (1, 3), (3, 1), (4, 1), (4, 3);" +
                "ALTER SEQUENCE activity_id RESTART WITH 5; " +
                "INSERT INTO users (internal_id, email, password) VALUES (1, 'user1@email.com', 'password1'), " +
                "(2, 'user2@email.com', 'password2'); " +
                "INSERT INTO maintainer (internal_id, name, email) VALUES (1, 'UserName1', 'user1@email.com'), " +
                "(2, 'UserName2', 'user2@email.com'); " +
                "INSERT INTO daily_time_slot (id, hour_start, duration)  " +
                "VALUES (1, '06:00:00', 60), (2, '07:00:00', 60), (3, '08:00:00', 60);" +
                "INSERT INTO assigned_activity (activity, maintainer) VALUES (1, 1), (2, 2), (3, 1), (4, 2); " +
                "INSERT INTO assigned_slot (assigned_activity, daily_time_slot, minutes) VALUES (1, 2, 30), (2, 2, 60), (2, 3, 30), (3, 2, 20), (4, 1, 40); " +
                "INSERT INTO maintainer_role (id, name, description) " +
                "VALUES (1, 'Role 1', 'Description role 1.'), (2, 'Role 2', 'Description role 2.'), (3, 'Role 3', 'Description role 3.'); " +
                "INSERT INTO competences (id, name, description) " +
                "VALUES (1, 'Skill 1', 'Description skill 1.')," +
                "(2, 'Skill 2', 'Description skill 2.'), " +
                "(3, 'Skill 3', 'Description skill 3.')," +
                "(4, 'Skill 4', 'Description skill 4.'), " +
                "(5, 'Skill 5', 'Description skill 5.'), " +
                "(6, 'Skill 6', 'Description skill 6.');" +
                "INSERT INTO has_skill (maintainer_role, competences) VALUES (1, 1), (1, 2), (1, 3), (2, 4), (2, 5), (2, 6); " +
                "INSERT INTO is_a (maintainer, maintainer_role) VALUES (1, 1), (2, 2); " +
                "INSERT INTO require (maintenance_procedures, competences) VALUES (1, 1), (1, 3), (1, 4), (1, 5), (2, 4), (2, 5), (2, 6); ";
        try (Statement stmt = db.getConn().createStatement()) {
            stmt.execute(populateQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @AfterEach
    void tearDown() {
        String deleteQuery = "DELETE FROM need CASCADE; " +
                "DELETE FROM materials CASCADE; ALTER SEQUENCE materials_id RESTART WITH 1; " +
                "DELETE FROM users CASCADE; " +
                "DELETE FROM assigned_slot CASCADE; " +
                "DELETE FROM assigned_activity CASCADE; " +
                "DELETE FROM is_a CASCADE; " +
                "DELETE FROM maintainer CASCADE; " +
                "DELETE FROM daily_time_slot CASCADE; " +
                "DELETE FROM activity CASCADE; ALTER SEQUENCE activity_id RESTART WITH 1; " +
                "DELETE FROM maintenance_typologies CASCADE; " +
                "DELETE FROM require CASCADE; " +
                "DELETE FROM maintenance_procedures CASCADE; " +
                "DELETE FROM has_skill CASCADE; " +
                "DELETE FROM maintainer_role CASCADE; " +
                "DELETE FROM competences CASCADE; " +
                "DELETE FROM site CASCADE; " +
                "DELETE FROM area CASCADE;" +
                "DELETE FROM factory_site CASCADE; " +
                "ALTER SEQUENCE workspace_notes_id RESTART WITH 1;" +
                "DELETE FROM workspace_notes CASCADE;" +
                "ALTER SEQUENCE activity_id RESTART WITH 1;";
        try (Statement stmt = db.getConn().createStatement()){
            stmt.execute(deleteQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        db.disconnect();
    }

    @Test
    void doGetWeeklyOne() throws IOException {
        // TRY GET
        HttpURLConnection http = (HttpURLConnection) new URL("http://localhost:8080/availability-weekly?activity-id=1&maintainer-id=1").openConnection();
        http.connect();

        assertEquals(HttpStatus.OK_200, http.getResponseCode());

        String expected = "{\"id\":\"1\",\"name\":\"UserName1\",\"competence_compliance\":\"2/4\",\"availability\":[{\"day\":\"1\",\"percentage\":\"72\"},{\"day\":\"2\",\"percentage\":\"100\"},{\"day\":\"3\",\"percentage\":\"100\"},{\"day\":\"4\",\"percentage\":\"100\"},{\"day\":\"5\",\"percentage\":\"100\"},{\"day\":\"6\",\"percentage\":\"100\"},{\"day\":\"7\",\"percentage\":\"100\"}]}";
        assertEquals(expected, tester.readPage(http));
    }

    @Test
    void doGetDailyOne() throws IOException {
        // TRY GET
        HttpURLConnection http = (HttpURLConnection) new URL("http://localhost:8080/availability-daily?activity-id=1&maintainer-id=2&day=1").openConnection();
        http.connect();

        assertEquals(HttpStatus.OK_200, http.getResponseCode());

        String expected = "{\"id\":\"2\",\"name\":\"UserName2\",\"competence_compliance\":\"2/4\",\"availability\":[{\"id\":\"1\",\"description\":\"06:00-07:00\",\"minutes\":\"20\"},{\"id\":\"2\",\"description\":\"07:00-08:00\",\"minutes\":\"0\"},{\"id\":\"3\",\"description\":\"08:00-09:00\",\"minutes\":\"30\"}]}";
        assertEquals(expected, tester.readPage(http));
    }

    @Test
    void doGetDailyOne2() throws IOException {
        // TRY GET
        HttpURLConnection http = (HttpURLConnection) new URL("http://localhost:8080/availability-daily?activity-id=1&maintainer-id=2&day=2").openConnection();
        http.connect();

        assertEquals(HttpStatus.OK_200, http.getResponseCode());

        String expected = "{\"id\":\"2\",\"name\":\"UserName2\",\"competence_compliance\":\"2/4\",\"availability\":[{\"id\":\"1\",\"description\":\"06:00-07:00\",\"minutes\":\"60\"},{\"id\":\"2\",\"description\":\"07:00-08:00\",\"minutes\":\"60\"},{\"id\":\"3\",\"description\":\"08:00-09:00\",\"minutes\":\"60\"}]}";
        assertEquals(expected, tester.readPage(http));
    }

    @Test
    void doGetWeeklyAll() throws IOException {
        // TRY GET
        HttpURLConnection http = (HttpURLConnection) new URL("http://localhost:8080/availability-weekly?activity-id=1").openConnection();
        http.connect();

        assertEquals(HttpStatus.OK_200, http.getResponseCode());

        String expected = "[{\"id\":\"1\",\"name\":\"UserName1\",\"competence_compliance\":\"2/4\",\"availability\":[{\"day\":\"1\",\"percentage\":\"72\"},{\"day\":\"2\",\"percentage\":\"100\"},{\"day\":\"3\",\"percentage\":\"100\"},{\"day\":\"4\",\"percentage\":\"100\"},{\"day\":\"5\",\"percentage\":\"100\"},{\"day\":\"6\",\"percentage\":\"100\"},{\"day\":\"7\",\"percentage\":\"100\"}]},{\"id\":\"2\",\"name\":\"UserName2\",\"competence_compliance\":\"2/4\",\"availability\":[{\"day\":\"1\",\"percentage\":\"27\"},{\"day\":\"2\",\"percentage\":\"100\"},{\"day\":\"3\",\"percentage\":\"100\"},{\"day\":\"4\",\"percentage\":\"100\"},{\"day\":\"5\",\"percentage\":\"100\"},{\"day\":\"6\",\"percentage\":\"100\"},{\"day\":\"7\",\"percentage\":\"100\"}]}]";
        assertEquals(expected, tester.readPage(http));
    }

    @Test
    void doGetDailyAll() throws IOException {
        // TRY GET
        HttpURLConnection http = (HttpURLConnection) new URL("http://localhost:8080/availability-daily?activity-id=1&day=1").openConnection();
        http.connect();

        assertEquals(HttpStatus.OK_200, http.getResponseCode());


        String expected = "[{\"id\":\"1\",\"name\":\"UserName1\",\"competence_compliance\":\"2/4\",\"availability\":[{\"id\":\"1\",\"description\":\"06:00-07:00\",\"minutes\":\"60\"},{\"id\":\"2\",\"description\":\"07:00-08:00\",\"minutes\":\"10\"},{\"id\":\"3\",\"description\":\"08:00-09:00\",\"minutes\":\"60\"}]},{\"id\":\"2\",\"name\":\"UserName2\",\"competence_compliance\":\"2/4\",\"availability\":[{\"id\":\"1\",\"description\":\"06:00-07:00\",\"minutes\":\"20\"},{\"id\":\"2\",\"description\":\"07:00-08:00\",\"minutes\":\"0\"},{\"id\":\"3\",\"description\":\"08:00-09:00\",\"minutes\":\"30\"}]}]";
        assertEquals(expected, tester.readPage(http));
    }

    @Test
    void doGetDailyMissingParameters() throws IOException {
        // TRY GET
        HttpURLConnection http = (HttpURLConnection) new URL("http://localhost:8080/availability-daily").openConnection();
        http.connect();

        assertEquals(HttpStatus.BAD_REQUEST_400, http.getResponseCode());
    }

    @Test
    void doGetWeeklyMissingParameters() throws IOException {
        // TRY GET
        HttpURLConnection http = (HttpURLConnection) new URL("http://localhost:8080/availability-weekly").openConnection();
        http.connect();

        assertEquals(HttpStatus.BAD_REQUEST_400, http.getResponseCode());
    }
}