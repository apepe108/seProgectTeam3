
/**
 * SELECTED_SERVICE_ENDPOINT
 * @type string
 *
 * Selected service endpoint
 */
const SELECTED_SERVICE_ENDPOINT = "http://" + "localhost:8080/DbManageService";
